/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg123220159_responsipbo;

/**
 *
 * @author DELL
 */
public class Main {
    public static void main(String[] args) {
        new ViewData();
        new ViewDataDosen();
    }
    
}
